﻿var http = require("http");
var qs = require('querystring');
var stringBuilder = require('stringbuilder');
var port = 9000;

function getHome(req, resp){
    resp.writeHead(200, { "Content-Type" : "text/html" });
    resp.write("<html><head><title>Calculator</title></head><body>Want to perform calculations.Click  <a href='/calc'>here</a></body></html>");
    resp.end();
}

function get404(req, resp) {
    resp.writeHead(404, { "Content-Type" : "text/html" });
    resp.write("<html><head><title>404 Error</title></head><body><h1> 404 Error</h1> Go to<a href='/'>home page</a></body></html>");
    resp.end();
}
function get405(req, resp) {
    resp.writeHead(405, { "Content-Type" : "text/html" });
    resp.write("<html><head><title>405 Error</title></head><body><h2> 405 Error </h2>Got to<a href='/'>home page</a></body></html>");
    resp.end();
}

function getCalcForm(req, resp, data) {
    var sb = new stringBuilder({newline: "\r\n"});
    sb.appendLine("<html>");
    sb.appendLine("<body>");
    sb.appendLine("<form method='post'>");
    sb.appendLine("<table>");

    sb.appendLine("<tr>");
    sb.appendLine("<td> enter first number: </td>");
    if (data && data.txtFirstNo) {
        sb.appendLine("<td> <input type='text' id='txtFirstNo' name='txtFirstNo' value='{0}'> </td>", data.txtFirstNo);
    } else {
        sb.appendLine("<td> <input type='text' id='txtFirstNo' name='txtFirstNo' value=''> </td>");
    }
    sb.appendLine("</tr>");

    sb.appendLine("<tr>");
    sb.appendLine("<td> enter Second number: </td>");
    if (data && data.txtSecondNo) {
        sb.appendLine("<td> <input type='text' id='txtSecondNo' name='txtSecondNo' value='{0}'> </td>", data.txtSecondNo);
    } else {
        sb.appendLine("<td> <input type='text' id='txtSecondNo' name='txtSecondNo' value=''> </td>");
    }
    sb.appendLine("</tr>");
    
    sb.appendLine("<tr>");
    sb.appendLine("<td> <input type='submit' value='Calculate'> </td>");
    sb.appendLine("</tr>");
    
    if (data && data.txtFristNo && data.txtSecondNo) {
        var sum = parseInt(data.txtFristNo) + parseInt(data.txtSecondNo);
        
        sb.appendLine("<tr>");
        sb.appendLine("<td>Sum is: {0}</td>", sum);
        sb.appendLine("</tr>");
    }
    sb.appendLine("</table>");
    sb.appendLine("</form>");
    sb.appendLine("</body>");
    sb.appendLine("</html>");

    sb.build(function (err, result) {
        resp.writeHead(200, { "Content-Type" : "text/html" });
        resp.write(result);
        resp.end();
    });
}

function getCalcInfo(req, resp, fromData) {
    resp.writeHead(200, { "Content-Type" : "text/html" }); 
    getCalcForm(req, resp, fromData);
}

http.createServer(function (req, resp) {
    switch (req.method) {
        case "GET":
            if (req.url === "/") {
                getHome(req, resp);
            }
            else if (req.url === "/calc") {
                getCalcInfo(req, resp);
            }
            else {
                get404(req, resp);
            }
            break;
        case "POST":
            if (req.url === "/calc") {
                var reqBody = '';
                req.on(' ', function (data) {
                    reqBody += data;
                    if (reqBody.length > len7) {
                        resp.writeHead(500, 'The data u entered is too large', { 'Content -Type' : 'text/html' });
                        resp.write("<html><head><title>too much data</title></head><body>too much data</body></html>");
                        resp.end()
                    }
                });
                req.on('end', function (data) {
                    var formData = qs.parse(reqBody);
                    getCalcInfo(req, resp, formData);
                    console.log(reqBody);
                });

            }
            else {
                get404(req, resp);
            }
            break;
        default:
            get405(req, resp);
            break;
    }
}).listen(port);